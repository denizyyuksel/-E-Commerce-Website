<?php
  require_once "db.php" ;

  if ( isset($_GET["incr"])) {
      increaseCartItem($_GET["incr"]) ;
  }

  if ( isset($_GET["dec"])) {
      decreaseCartItem($_GET["dec"], $_GET["amount"]);
  }

  $products = getCartProducts() ;

  $total = 0 ;
  foreach($products as $p) {
      $total += $p["amount"] * $p["discounted price"] ;
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="app.css">
    <style>
    
    body {
  margin:40px;
}
* {
  box-sizing: border-box;
}
input {
  display:block;
  width:400px;
  margin:10px 0;
  padding:10px;
}


body {
    background-image: url('sus.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}

.s {
  align-items: center;
  background-image: linear-gradient(144deg,#AF40FF, #5B42F3 50%,#00DDEB);
  border: 0;
  border-radius: 8px;
  box-shadow: rgba(151, 65, 252, 0.2) 0 15px 30px -5px;
  box-sizing: border-box;
  color: white;
  display: flex;
  font-family: Phantomsans, sans-serif;
  font-size: 20px;
  justify-content: center;
  line-height: 1em;
  max-width: 150px;
  min-width: 140px;
  padding: 3px;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  white-space: nowrap;
 
}



.s span {
  background-color: rgb(5, 6, 45);
  padding: 16px 24px;
  border-radius: 6px;
  width: 100%;
  height: 100%;
  transition: 300ms;
}


}</style>
</head>

<body>
    <center>
    <h1 class="s">Shopping Cart</h1>
    <table class="center style1" >
        <?php if (count($products) == 0) : ?>
           <tr>
               <td colspan="3">Empty Cart</td>
           </tr>
        <?php else : ?>
            <?php foreach($products as $p) : ?>
               <tr>
                   <td><img src="images/<?= $p["image"]?>" style="width:100px"></td>
                   <br>
                   <td>
                       <p><?= $p["title"] ?></p><br>
                       <span class="price"><?= $p["discounted price"] * $p["amount"] ?> &#8378;</span>
                   </td>
                   <td class="center">
                       <a href="?incr=<?= $p["pid"]?>" class="s">+</a><br>
                       <span class="amount"><?= $p["amount"] ?></span><br>
                       <a href="?dec=<?= $p["pid"]?>&amount=<?= $p["amount"] ?>" class="s">-</a>
                   </td>
               </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="3"><h1><?= $total ?> &#8378;</h1></td>
            </tr>
        <?php endif ?>
    </table>
    <button class="s"><a href="?empty=1">Purchase</a></button>
    <p style="padding-left:30px"><a href="main.php" class="btn">&#8592;</a></p>
    <?php
    if(!empty($_GET['empty']))
    {
        $stmt = $db->prepare("truncate table cart");
        $stmt->execute();
        header("Location: cart.php") ;
        exit ; 
    }



    ?>
    </center>
</body>
</html>