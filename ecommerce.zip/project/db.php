<?php

const DSN = "mysql:host=localhost;dbname=test;port=3306;charset=utf8mb4" ;
const USER = "std" ;
const PASSWORD = "" ;


 $db = new PDO(DSN, USER, PASSWORD) ;
 
 function getCartProducts() {
    global $db ;
    $sql = "select * from product, cart where cart.pid = product.pid" ;
    return $db->query($sql)->fetchAll() ;
  }
 function addToCart($pid) {
    global $db ;

    $stmt = $db->prepare("select * from cart where pid=?") ;
    $stmt->execute([$pid]) ;
    if ( $stmt->rowCount()) {
      $stmt = $db->prepare("update cart set amount = amount + 1 where pid=?") ;
      $stmt->execute([$pid]) ;
    } else {
      $stmt = $db->prepare("insert into cart (pid, amount) values (?,1)") ;
      $stmt->execute([$pid]) ;
    }
  }
  
  function increaseCartItem($pid) {
    global $db ;

    $db->prepare("update cart set amount = amount + 1 where pid=?")
       ->execute([$pid]) ;
  }

  function decreaseCartItem($pid, $amount) {
    global $db ;

    if ( $amount == 1) {
      $db->prepare("delete from cart where pid=?")
         ->execute([$pid]) ;
    } else {
      $db->prepare("update cart set amount = amount - 1 where pid=?")
         ->execute([$pid]) ;
    }
  }
 function checkUser($email, $pass) {
     global $db ;

     $stmt = $db->prepare("select * from user where email=?") ;
     $stmt->execute([$email]) ;
     if ( $stmt->rowCount()) {
         $user = $stmt->fetch(PDO::FETCH_ASSOC) ;
         return $user["password"]==$pass ;
     }
  
     return false ;
 }

 function validSession() {
     return isset($_SESSION["user"]) ;
 }

 function getUser($email) {
     global $db ;
     $stmt = $db->prepare("select * from user where email=?") ;
     $stmt->execute([$email]);
     
     return $stmt->fetch(PDO::FETCH_ASSOC) ;
 }

