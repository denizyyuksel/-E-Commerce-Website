<?php
   session_start() ;
  require "db.php";
  $stmt = $db->prepare("truncate table cart");
  $stmt->execute();
   session_destroy() ;  // delete session file
   // delete cookie
   setcookie(session_name(), "", 1 , "/") ; // delete memory cookie 
   header("Location: login.php") ;