<?php
  session_start() ;
  require "db.php";
  require "Upload.php";
  
  // check if the user authenticated before
  if( !validSession()) {
      header("Location: login.php?error") ;
      exit ; 
  }
  $userData = $_SESSION["user"] ;
  ?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
   
    body {
  margin:40px;
}
* {
  box-sizing: border-box;
}
input {
  display:block;
  width:400px;
  margin:10px 0;
  padding:10px;
}


body {
    background-image: url('sus.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}

.s {
  align-items: center;
  background-image: linear-gradient(144deg,#AF40FF, #5B42F3 50%,#00DDEB);
  border: 0;
  border-radius: 8px;
  box-shadow: rgba(151, 65, 252, 0.2) 0 15px 30px -5px;
  box-sizing: border-box;
  color: #black;
  display: flex;
  font-family: Phantomsans, sans-serif;
  font-size: 20px;
  justify-content: center;
  line-height: 1em;
  max-width: 150px;
  min-width: 140px;
  padding: 3px;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  white-space: nowrap;
  cursor: pointer;
}

.s:active,
.s:hover {
  outline: 0;
}

.s span {
  background-color: rgb(5, 6, 45);
  padding: 16px 24px;
  border-radius: 6px;
  width: 100%;
  height: 100%;
  transition: 300ms;
}

.s:hover span {
  background: none;
}
.m {
  align-items: center;
  background-image: linear-gradient(144deg,#AF40FF, #5B42F3 50%,#00DDEB);
  border: 0;
  border-radius: 8px;
  box-shadow: rgba(151, 65, 252, 0.2) 0 15px 30px -5px;
  box-sizing: border-box;
  color: white;
  display: flex;
  font-family: Phantomsans, sans-serif;
  font-size: 20px;
  justify-content: center;
  line-height: 1em;
  max-width: 400px;
  min-width: 140px;
  padding: 3px;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  white-space: nowrap;
  cursor: pointer;
  text-decoration: none;
}

.m:active,
.m:hover {
  outline: 0;
}

.m span {
  background-color: rgb(5, 6, 45);
  padding: 16px 24px;
  border-radius: 6px;
  width: 100%;
  height: 100%;
  transition: 300ms;
}

.m:hover span {
  background: none;
}


    
    </style>
    <link href="themes/js/google-code-prettify/prettify.css" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <center>
   

    <div class="whole">
    <h1>Sustainable Smile</h1>
    <h3>Welcome <?= $userData["name"] ?></h3>
    
<h4><a href="?email=<?=$userData["email"]?>" class="m">Click here to update/edit information</a></h4>


<?php
  if(!empty($_GET["email"])){
    $id = $_GET["email"] ;
  ?>
  <form action="" method="post">
	<div class="control-group">
		<label class="control-label">Choose the field you want to edit<sup>*</sup></label>
		<div class="controls">
		<select class="s" name="editf">
			
			<option value="name" >name</option>
            <option value="password">password</option>
            <option value="city">city</option>
            <option value="district">district</option>
            <option value="address">address</option>
			
		</select>
        </div>
        </div>
        <div class="control-group">
			<label class="control-label" for="inputFname1">Enter the updated information: <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputFname1" name="edits" placeholder="" value="<?= isset($edits) ? filter_var($edits, FILTER_SANITIZE_FULL_SPECIAL_CHARS) : "" ?>">
			</div>
         </div>
         <div class="control-group">
			<div class="controls">
				<input class="s" width="80px" type="submit" value="Update" />
			</div>
		</div>
         </form>
  <?php
 if ( !empty($_POST)) {
    extract($_POST) ;

    if($editf=="city"){
    $stmt = $db->prepare("update user set city = ? where email=?") ;
}
    else if($editf=="name"){
        $stmt = $db->prepare("update user set name = ? where email=?") ;
    }
    else if($editf=="password"){
        $stmt = $db->prepare("update user set password = ? where email=?") ;
    }
    else if($editf=="address"){
        $stmt = $db->prepare("update user set address = ? where email=?") ;
    }
    else if($editf=="district"){
        $stmt = $db->prepare("update user set district = ? where email=?") ;
        
    }
    $stmt->execute([$edits,$id]) ;
  ;  }}
?>
<?php
    if($userData["role"]=="market"){
        if(!empty($_GET["name"])){
        $name=$_GET["name"];
        ?>
 <form action="" method="post" enctype="multipart/form-data">
	<div class="control-group">
			<label class="control-label" for="inputFname1">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputFname1" name="title" placeholder="title" value="<?= isset($title) ? filter_var($title, FILTER_SANITIZE_FULL_SPECIAL_CHARS) : "" ?>">
			</div>
         </div>
         <div class="control-group">
			<label class="control-label" for="inputFname1">Stock <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputFname1" name="stock" placeholder="stock" value="<?= isset($stock) ? filter_var($stock, FILTER_SANITIZE_FULL_SPECIAL_CHARS) : "" ?>">
			</div>
         </div>
         <div class="control-group">
			<label class="control-label" for="inputFname1">Normal Price <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputFname1" name="np" placeholder="np" value="<?= isset($np) ? filter_var($np, FILTER_SANITIZE_FULL_SPECIAL_CHARS) : "" ?>">
			</div>
         </div>
         <div class="control-group">
        <label class="control-label" for="inputFname1">Discounted Price <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputFname1" name="dp" placeholder="dp" value="<?= isset($dp) ? filter_var($dp, FILTER_SANITIZE_FULL_SPECIAL_CHARS) : "" ?>">
			</div>
		 </div>
         <div class="control-group">
			<label class="control-label" for="inputFname1">Expiration Date <sup>*</sup></label>
			<div class="controls">
			  <input type="date" id="inputFname1" name="ed" placeholder="ed" value="<?= isset($ed) ? filter_var($ed, FILTER_SANITIZE_FULL_SPECIAL_CHARS) : "" ?>">
			</div>
         </div>
         <div class="control-group">
			<label class="control-label" for="inputFname1">Image <sup>*</sup></label>
			<div class="controls">
			  <input type="file" id="inputFname1" name="image" placeholder="image" >
			</div>
		 </div>
         <button type="submit" class="s">Add</button>
         </form>

<?php

if ( !empty($_POST)) {
			
    $profile = new Upload("image", "images") ;
    $filename = $profile->file() ?? "profile.jpg" ;
    
    
    extract($_POST) ;

    $stock=intval($stock);
    $np=intval($np);
    $dp=intval($dp);
    
    try {
        $sql = "INSERT INTO `product` (`mname`, `title`, `stock`, `normal price`, `discounted price`, `expiration date`, `image`) values (?,?,?,?,?,?,?)";
        $stmt = $db->prepare($sql) ;
        $res = $stmt->execute([$userData["name"],$title, $stock, $np,$dp,$ed, $filename]) ;
    } catch(Exception $e)
    {
        echo $e->getMessage();
    }
}
        }
    

?>
<h4><a href="?name=<?=$userData["name"]?>"><button class="s">Add products</button></a></h4>
<?php } 
else {
   

   if ( isset($_GET["add"])) {
       addToCart($_GET["add"]) ;
   }

   $products = $db->query("select * from product")->fetchAll(PDO::FETCH_ASSOC) ;
   $cartSize = $db->query("select sum(amount) from cart")->fetch()[0] ;


    ?>
     <header>
     <button class="m"><a href="search.php">Search ?</a></button>
        <div>
            <br>
        <a href="cart.php" class="m">
            Shopping Cart <?= $cartSize > 0 ? "($cartSize)" : "" ?>
        </a>    
        </div>
    </header>
    <h1>PRODUCTS</h1>
    <tr>
            <td></td>
            <td>Title</td>
            <td>Expiration Date</td>
            <td>Discounted Price</td>
        </tr>
    <table class="center style1" >
        <?php 
        
        
        foreach( $products as $p) : ?>
        
            <tr>

            <td><img src="images/<?=$p["image"] ?>" style="width:100px"></td>
            <td><?= $p["title"] ?></td>
            <td><?= $p["expiration date"] ?></td>
                <td><?= $p["discounted price"] ?> &#8378;</td>
                <td>
                    <a  href="?add=<?= $p["pid"] ?>" class="m">Add</a>
                </td>

            </tr>
        <?php  endforeach ; ?>
    </table>
   
<?php } 

    ?>
    <div class="s" >
        <a  href="logout.php" >Logout</a>
        </div>
    </div>
    </center>
</body>
</html>