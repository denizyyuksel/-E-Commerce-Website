-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 15, 2022 at 07:22 PM
-- Server version: 5.7.21
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `mname` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `stock` int(30) NOT NULL,
  `normal price` int(30) NOT NULL,
  `discounted price` int(11) NOT NULL,
  `expiration date` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `image` varchar(60) COLLATE utf8mb4_turkish_ci NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `mname`, `title`, `stock`, `normal price`, `discounted price`, `expiration date`, `image`) VALUES
(1, 'MIGROS', 'Yerli Muz', 12, 5, 3, '2022-05-17', 'muzz.jpg'),
(3, 'MIGROS', 'Granny Smith Elma', 12, 8, 5, '2022-05-18', 'img.jpg'),
(4, 'MIGROS', 'Çilek Gaziantep', 21, 21, 20, '2022-05-25', 'str.jpg'),
(16, 'bim', 'Garnier Yüz Temizleme Jeli', 32, 30, 25, '2022-05-27', '6c4d1fe909f98b6fecabafc64beb104d9ff47452.jpg'),
(15, 'MIGROS', 'Dove Avocado Özlü Şampuan', 3, 44, 40, '2022-05-27', 'dove.jpg'),
(17, 'bim', 'Sütaş Tereyağı 350 g', 21, 50, 40, '2022-05-18', 'b6771e7f310b446bbcf556faa1942b944b341f67.jpg'),
(18, 'Amazon', 'GERBER Organik Armut Elma ve Muz Püresi 90 g', 32, 20, 14, '2022-05-26', 'a94107c7558704978a717351c578f0f1bda581b3.jpg'),
(19, 'Amazon', 'SMA OPTIPRO 2 6-12 Ay Devam Sütü 800 g', 23, 150, 140, '2022-05-20', 'e9bcc90e1dda5a7f31ac7724ab1144b1365493ee.jpg'),
(20, 'Amazon', 'Hero Baby Organik Elmalı Şeftalili 120 G', 2, 10, 7, '2022-05-26', 'b4abf7cd1c6e24c9fc87a0c14f151491eed26a2e.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
