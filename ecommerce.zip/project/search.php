<?php
session_start() ;
require "db.php" ;
$searchErr = '';
$employee_details='';
if(isset($_POST['save']))
{
    if(!empty($_POST['search']))
    {
        $search = $_POST['search'];
        $cadd=$_SESSION["user"];
        $cadd=$cadd["email"];
      
        $guadd=$db->prepare("select city from user where email like '%$cadd%' "); 
        $guadd->execute(); 
        $guadd=$guadd->fetchAll(PDO::FETCH_ASSOC);
        
        $g=$guadd[0]['city'];
                $madd=$db->prepare("select name from user where city like '%$g%' and role='market'"); 
        $madd->execute();
        $madd=$madd->fetchAll(PDO::FETCH_ASSOC);

        foreach( $madd as $p){
            
            $m= $p["name"]; 
            $stmt = $db->prepare("select * from product where title like '%$search%' and mname like '%$m%' ");
            $stmt->execute();
            
            $employee_details = $stmt->fetchAll(PDO::FETCH_ASSOC);
                 
                }
      
       
       
         
    }
    else
    {
        $searchErr = "Product not found";
    }
    
}
 
?>
<html>
<head>
<title> Search Products</title>

<style>
.container{
    width:70%;
    height:30%;
    padding:20px;
}
body {
    background-image: url('sus.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}

.s {
  align-items: center;
  background-image: linear-gradient(144deg,#AF40FF, #5B42F3 50%,#00DDEB);
  border: 0;
  border-radius: 8px;
  box-shadow: rgba(151, 65, 252, 0.2) 0 15px 30px -5px;
  box-sizing: border-box;
  color: #black;
  display: flex;
  font-family: Phantomsans, sans-serif;
  font-size: 20px;
  justify-content: center;
  line-height: 1em;
  max-width: 150px;
  min-width: 140px;
  padding: 3px;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  white-space: nowrap;
  cursor: pointer;
}

.s:active,
.s:hover {
  outline: 0;
}

.s span {
  background-color: rgb(5, 6, 45);
  padding: 16px 24px;
  border-radius: 6px;
  width: 100%;
  height: 100%;
  transition: 300ms;
}

.s:hover span {
  background: none;
}
.m {
  align-items: center;
  background-image: linear-gradient(144deg,#AF40FF, #5B42F3 50%,#00DDEB);
  border: 0;
  border-radius: 8px;
  box-shadow: rgba(151, 65, 252, 0.2) 0 15px 30px -5px;
  box-sizing: border-box;
  color: white;
  display: flex;
  font-family: Phantomsans, sans-serif;
  font-size: 20px;
  justify-content: center;
  line-height: 1em;
  max-width: 400px;
  min-width: 140px;
  padding: 3px;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  white-space: nowrap;
  cursor: pointer;
  text-decoration: none;
}

.m:active,
.m:hover {
  outline: 0;
}

.m span {
  background-color: rgb(5, 6, 45);
  padding: 16px 24px;
  border-radius: 6px;
  width: 100%;
  height: 100%;
  transition: 300ms;
}

.m:hover span {
  background: none;
}
table{
    border-spacing: 50px 0;
    
}

</style>
</head>
 
<body>
    <center>
    <div class="container">
   
    <form action="#" method="post">
    <div class="row">
        <div >
            <label ><b>Please enter the  product to search</b>:</label>
            <br>
            <br>
            <div>
              <input type="text" name="search" placeholder="search here">
              <br>
              <br>
            </div>
            <div >
              <button type="submit" class="m" name="save">Search</button>
            </div>
            <br>
        </div>
        
         
    </div>
    </form>
    <br/><br/>
    
            
     
        <tbody>
                <?php
                 if(!$employee_details)
                 {
                    
                 }
                 else{
                     ?>
                     <button class="m"><a href="main.php">Go To Main</a></button>
         <br><br>
                     <h3><u>Search Result</u></h3><br/>
                      <table class="table">
                          
        <thead>
          <tr >
            <th>#</th>
            <th>Market Name</th>
            <th>Product Name</th>
            <th>Normal Price</th>
            <th>Discounted Price</th>
            <th>Image</th>
          </tr>
        </thead>
        <?php
                    foreach($employee_details as $key=>$value)
                    {
                        ?>
                    <tr>
                        
                        <td><?php echo $key+1;?></td>
                        <td><?php echo $value['mname'];?></td>
                        <td><?php echo $value['title'];?></td>
                        <td><?php echo $value['normal price'];?></td>
                        <td><?php echo $value['discounted price'];?></td>
                        <td><img src="images/<?=$value["image"] ?>" style="width:100px"></td>
                    </tr>
                         
                        <?php
                    }
                     
                 }
                ?>
             
         </tbody>
         
         
      </table>
    </div>
</div>

<div >
            <span class="error" style="color:red;"> <?php echo $searchErr;?></span>
        </div>
        
</center>
</body>
</html>